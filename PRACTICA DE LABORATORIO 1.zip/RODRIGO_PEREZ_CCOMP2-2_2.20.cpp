// RODRIGO SANTOS PEREZ M CCOMP2-2

# include <iostream>
using namespace std;
int main() {
    int radio{0};
    float pi{0};
    pi = 3.14159;
    int diametro{0};
    float circunferencia{0};
    float area{0};

    cout << "Ingrese el radio del circulo:" << endl;
    cin >> radio;

    diametro = 2*radio;
    cout << "El diametro del circulo es: " << diametro << endl;

    circunferencia = 2*radio*pi;
    cout << "La circunferencia del circulo es: " << circunferencia << endl;

    area = pi*radio*radio;
    cout << "El area del circulo es: " << area << endl;
    
    return 0;
}