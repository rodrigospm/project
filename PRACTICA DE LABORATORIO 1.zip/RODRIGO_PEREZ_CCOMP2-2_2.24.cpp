// RODRIGO SANTOS PEREZ M CCOMP2-2

# include <iostream>
using namespace std;
int main() {
    int n1{0};
    int n2{0};
    int sum{0};

    cout << "Ingrese 2 numeros enteros: " << endl;
    cin >> n1 >> n2;

    if (n1 % 2 > 0) {
        cout << "El numero " << n1 << " es impar" << endl;
    }
    else {
        cout << "El numero " << n1 << " es par" << endl;
    }

    if (n2 % 2 > 0) {
        cout << "El numero " << n2 << " es impar" << endl;
    }
    else {
        cout << "El numero " << n2 << " es par" << endl;
    }

    sum = n1 + n2;
    if (sum % 2 > 0) {
        cout << "La suma de los 2 numeros ingresados " << sum << " es impar" << endl;
    }
    else {
        cout << "La suma de los 2 numeros ingresados " << sum << " es par" << endl;
    }
    
    return 0;
}