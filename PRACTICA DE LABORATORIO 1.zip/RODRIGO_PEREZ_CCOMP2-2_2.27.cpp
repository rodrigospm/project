// RODRIGO SANTOS PEREZ M CCOMP2-2

# include <iostream>
using namespace std;
int main() {
    char caracter;

    cout << "Ingrese un caracter y se mostrara su numero equivalente: ";
    cin >> caracter;
    cout << static_cast<int>(caracter);
    
    return 0;
}
