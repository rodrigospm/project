// RODRIGO SANTOS PEREZ M CCOMP2-2

# include <iostream>
using namespace std;
int main() {
    int n1{0};
    int n2{1};
    int n3{2};
    int n4{3};
    int n5{4};

    cout << "Face lenght\tSurface area\tVolume" << endl;
    cout << "of cube (cm)\tof cube (cm^2)\tof cube (cm^3)" << endl;
    cout << n1 << "\t\t" << 6*n1*n1 << "\t\t" << n1*n1*n1 << endl;
    cout << n2 << "\t\t" << 6*n2*n2 << "\t\t" << n2*n2*n2 << endl;
    cout << n3 << "\t\t" << 6*n3*n3 << "\t\t" << n3*n3*n3 << endl;
    cout << n4 << "\t\t" << 6*n4*n4 << "\t\t" << n4*n4*n4 << endl;
    cout << n5 << "\t\t" << 6*n5*n5 << "\t\t" << n5*n5*n5;

    return 0;
}