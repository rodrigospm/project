// RODRIGO SANTOS PEREZ M CCOMP2-2

// (MotorVehicle class) Create a class called MotorVehicle that represents a motor vehicle
// using: make (type string), fuelType (type string), yearOfManufacture (type int), color (type string)
// and engineCapacity (type int). Your class should have a constructor that initializes the three
// data members. Provide a set and a get function for each data member. Add a member function
// called displayCarDetails that displays the five data members in five separate lines in the form
// "member name: member value". Write a test program to demonstrate MotorVehicle’s capabilities.|

# include <string>
# include <iostream>
using namespace std;

class MotorVehicle {
    public:
        MotorVehicle(string makeTemp, string fuelTypeTemp, int yearOfManufactureTemp, string colorTemp, int engineCapacityTemp) {
            make = makeTemp;
            fuelType = fuelTypeTemp;
            yearOfManufacture = yearOfManufactureTemp;
            color = colorTemp;
            engineCapacity = engineCapacityTemp;
        };

        void setMake(string makeTemp) {
            make = makeTemp;
        }

        string getMake() const {
            return make;
        }

        void setFuelType(string fuelTypeTemp) {
            fuelType = fuelTypeTemp;
        }

        string getFuelType() const {
            return fuelType;
        }

        void setYearOfManufacture(int yearOfManufactureTemp) {
            yearOfManufacture = yearOfManufactureTemp;
        }

        int getYearOfManufacture() const {
            return yearOfManufacture;
        }

        void setColor(string colorTemp) {
            color = colorTemp;
        }

        string getColor() const {
            return color;
        }

        void setEngineCapacity(int engineCapacityTemp) {
            engineCapacity = engineCapacityTemp;
        }

        int getEngineCapacity() const {
            return engineCapacity;
        }

        void displayCarDetails() {
           cout << "Motor Vehicle's make: " << make << endl;
           cout << "Motor Vehicle's fuel type: " << fuelType << endl;
           cout << "Motor Vehicle's year of manufacture: " << yearOfManufacture << endl;
           cout << "Motor Vehicle's color: " << color << endl;
           cout << "Motor Vehicle's engine capacity: " << engineCapacity << endl;
        }

    private:
        string make;
        string fuelType;
        int yearOfManufacture{0};
        string color;
        int engineCapacity{0};
};