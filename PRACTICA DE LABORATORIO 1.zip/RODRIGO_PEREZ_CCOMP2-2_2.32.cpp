// RODRIGO SANTOS PEREZ M CCOMP2-2

# include <iostream>
using namespace std;
int main() {
    int age{0};
    int mhr{0};

    cout << "Ingrese su edad: " << endl;
    cin >> age;
    mhr = 220 - age;
    cout << "Su MHR es de: " << mhr << endl;

    return 0;
}
