// RODRIGO SANTOS PEREZ M CCOMP2-2

# include <iostream>
using namespace std;
int main() {
    int x{0};
    int r{0};

    cout << "Ingrese un entero de 4 digitos: " << endl;
    cin >> x;

    r = x % 10;
    cout << r << "  ";
    r = (x / 10) % 10;
    cout << r << "  ";
    r = (x / 100) % 10;
    cout << r << "  ";
    r = (x / 1000) % 10;
    cout << r << "  ";

    return 0;
}
