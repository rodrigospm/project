// RODRIGO SANTOS PEREZ M CCOMP2-2

# include <iostream>
using namespace std;
int main() {

    cout << "  CCC" << "\t" << "  +  " << "\t" << "  +  " << endl;
    cout << " C   " << "\t" << "  +  " << "\t" << "  +  " << endl;
    cout << "C    " << "\t" << "+++++" << "\t" << "+++++" << endl;
    cout << " C   " << "\t" << "  +  " << "\t" << "  +  " << endl;
    cout << "  CCC" << "\t" << "  +  " << "\t" << "  +  " << endl;
    
    return 0;
}