// RODRIGO SANTOS PEREZ M CCOMP2-2

# include <iostream>
using namespace std;
int main() {
    int a{0};
    int b{0};
    int c{0};
    int d{0};
    int e{0};
    int costo{0};

    cout << "Total de millas conducidas por dia: " << endl;
    cin >> a;
    cout << "Costo por galon de gasolina: " << endl;
    cin >> b;
    cout << "Promedio de millas por galon: " << endl;
    cin >> c;
    cout << "Tarifas de parking por dia: " << endl;
    cin >> d;
    cout << "Peajes por dia: " << endl;
    cin >> e;

    costo = ((a / c)* b)+ d + e;
    
    cout << "El costo es de: " << costo << endl;

    return 0;
}