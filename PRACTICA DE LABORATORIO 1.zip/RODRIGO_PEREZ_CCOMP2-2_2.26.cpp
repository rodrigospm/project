// RODRIGO SANTOS PEREZ M CCOMP2-2 # Otra foram es multiplicando el string x 4
# include <iostream>
int main() {
    std::cout << "* * * * * * * * \n * * * * * * * *" << std::endl;   
    std::cout << "* * * * * * * * \n * * * * * * * *" << std::endl;   
    std::cout << "* * * * * * * * \n * * * * * * * *" << std::endl;   
    std::cout << "* * * * * * * * \n * * * * * * * *" << std::endl; 
    return 0; }