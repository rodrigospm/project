// RODRIGO SANTOS PEREZ M CCOMP2-2

// (Date Class) Create a class called Date that includes three pieces of information as data
// members—a month (type int), a day (type int) and a year (type int). Your class should have a con-
// structor with three parameters that uses the parameters to initialize the three data members. For the
// purpose of this exercise, assume that the values provided for the year and day are correct, but ensure
// that the month value is in the range 1–12; if it isn’t, set the month to 1. Provide a set and a get func-
// tion for each data member. Provide a member function displayDate that displays the month, day
// and year separated by forward slashes (/). Write a test program that demonstrates class Date’s capa-
// bilities.

# include <string>

# include <string>
# include <iostream>
using namespace std;

class Date { 
    public:
        Date(int monthTemp, int dayTemp, int yearTemp){ 
            if (monthTemp < 12) {
            month = monthTemp;
            }
            day = dayTemp;          
            year = yearTemp;
        };

        void setMonth(int monthTemp) {
            month = monthTemp;
        }

        int getMonth() const {
            return month;
        }

        void setDay(int dayTemp) {
            day = dayTemp;
        }

        int getDay() const {
            return day;
        }

        void setYear(int yearTemp) {
            year = yearTemp;
        }

        int getYear() const {
            return year;
        }

        void displayDate() {
           cout << "Date: " << month << " // " << day << " // " << year << endl;
        }

    private:
        int month{1};
        int day{0};
        int year{0};
};