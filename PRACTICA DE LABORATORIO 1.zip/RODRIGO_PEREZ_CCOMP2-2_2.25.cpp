// RODRIGO SANTOS PEREZ M CCOMP2-2

# include <iostream>
using namespace std;
int main() {
    int n1{0};
    int n2{0};
    int n3{0};

    cout << "Ingrese 3 numeros enteros: " << endl;
    cin >> n1 >> n2 >> n3;

    if (n3 % n1 == 0) {
        cout << "El numero " << n1 << " es factor de " << n3;
    }
    else {
        cout << "El numero " << n1 << " no es factor de " << n3;
    }

    if (n3 % n2 == 0) {
        cout << "\nEl numero " << n2 << " es factor de " << n3;
    }
    else {
        cout << "\nEl numero " << n2 << " no es factor de " << n3;
    }

    return 0;
}
