// RODRIGO SANTOS PEREZ M CCOMP2-2

# include <iostream>
using namespace std;
int main() {

    int n1{0};
    int n2{0};
    int n3{0};
    int n4{0};
    int n5{0};   
    int pequeño{0};
    int grande{0}; 
    cout << "Ingrese 5 numeros para compararlos:" << endl;
    cin >> n1 >> n2 >> n3 >> n4 >> n5;
    grande = n1;
    pequeño = n1;
    if (n2 > grande) {
        grande = n2;
    }
    if (n3 > grande) {
        grande = n3;
    }
    if (n4 > grande) {
        grande = n4;
    }
    if (n5 > grande) {
        grande = n5;
    }
    
    if (n2 < pequeño) {
        pequeño = n2;
    }
    if (n3 < pequeño) {
        pequeño = n3;
    }
    if (n4 < pequeño) {
        pequeño = n4;
    }
    if (n5 < pequeño) {
        pequeño = n5;
    }

    cout << "El numero mas grande es: " << grande << endl;
    cout << "El numero mas pequeno es: " << pequeño << endl;

    return 0;
}