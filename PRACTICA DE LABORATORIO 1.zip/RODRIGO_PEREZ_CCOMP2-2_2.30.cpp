// RODRIGO SANTOS PEREZ M CCOMP2-2

# include <iostream>
using namespace std;
int main() {
    float peso{0};
    float altura{0};
    float bmi{0};

    cout << "BMI VALUES" << endl;
    cout << "Bajopeso: \t menos de 18.5" << endl;
    cout << "Normal: \t entre 18.5 y 24.9" << endl;
    cout << "Sobrepeso: \t entre 25 y 29.9" << endl;
    cout << "Obeso: \t\t 30 o mas\n" << endl;

    cout << "Ingrese su peso (kg): " << endl;
    cin >> peso;
    cout << "Ingrese su altura (m): " << endl;
    cin >> altura;

    bmi = peso/(altura*altura);

    cout << "Su IBM es de: " << bmi;

    return 0;
}